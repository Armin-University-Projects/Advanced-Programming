﻿// This program generates a sudoku table for the user to solve

using System;

namespace Sudoku
{
    public class Program
    {
        static void Main()
        {
            SudokuTable NewSudokuTable = new();

            while (NewSudokuTable.ShowMenu()) ;
        }
    }

    public class SudokuTable
    {
        public enum Difficulty { Diffault, Easy, Normal, Hard };
        public static readonly int NumberOfDifficulties = 4;
        private bool HasBeenShown = false;

        private readonly int[] EmptyCells = new int[NumberOfDifficulties]; // for each difficulty
        private int EmptyCellsNum;

        private int NumberOfHints = 3;
        public static readonly int CellsToFill_ForEachHint = 3;

        public static readonly int SideLength = 9;
        public static readonly int BlockLength = 3;
        private int[] NumbersList = { 1, 2, 3, 4, 5, 6, 7, 8, 9 }; // for filling the table

        private int[,] Table = new int[SideLength, SideLength];
        private int[,] SolvedTable = new int[SideLength, SideLength];
        private bool[,] IsNative = new bool[SideLength, SideLength];

        private readonly int[,] DefaultTable = { { 0 , 8 , 4  ,  0 , 0 , 0  ,  0 , 1 , 3 },
                                                 { 2 , 0 , 0  ,  0 , 3 , 0  ,  6 , 0 , 0 },
                                                 { 6 , 0 , 0  ,  5 , 0 , 9  ,  0 , 0 , 2 },

                                                 { 0 , 0 , 2  ,  0 , 0 , 0  ,  4 , 6 , 9 },
                                                 { 7 , 0 , 0  ,  0 , 0 , 0  ,  0 , 0 , 0 },
                                                 { 0 , 0 , 0  ,  2 , 8 , 0  ,  0 , 0 , 0 },

                                                 { 0 , 2 , 0  ,  7 , 0 , 0  ,  0 , 0 , 0 },
                                                 { 0 , 0 , 8  ,  0 , 0 , 5  ,  9 , 0 , 6 },
                                                 { 5 , 0 , 0  ,  0 , 2 , 0  ,  3 , 0 , 7 } };

        private static readonly ConsoleColor Background_Color = ConsoleColor.Black;
        private static readonly ConsoleColor User_Color = ConsoleColor.DarkGreen;
        private static readonly ConsoleColor Special_Color = ConsoleColor.Yellow;
        private static readonly ConsoleColor Number_Color = ConsoleColor.White;
        private static readonly ConsoleColor Text_Color = ConsoleColor.Gray;
        private static readonly ConsoleColor Selection_Color = ConsoleColor.DarkCyan;
        private static readonly ConsoleColor Success_Color = ConsoleColor.Green;
        private static readonly ConsoleColor Failure_Color = ConsoleColor.DarkGray;
        private static readonly ConsoleColor Error_Color = ConsoleColor.Red;

        public SudokuTable()
        {
            CreationMenu(out Difficulty difficulty);

            EmptyCells[(int)Difficulty.Diffault] = 53;

            for (int i = 1, EmptyNum = 50; i < NumberOfDifficulties; i++, EmptyNum += 10)
            {
                EmptyCells[i] = new Random().Next(EmptyNum, EmptyNum + 5) * SideLength * SideLength / 100;
                //                               percentage of empty cells
                // percentages:
                // easy: 50 to 55 
                // normal: 60 to 65
                // hard: 70 to 75
            }

            CreateTable(difficulty);
        }

        private void CreateTable(Difficulty difficulty)
        {
            if (difficulty == Difficulty.Diffault)
            {
                Table = DefaultTable;
                EmptyCellsNum = EmptyCells[(int)difficulty];
                Solve();
            }
            else
            {
                Shuffle();
                Solve(); // generating a table

                for (int i = 0; i < SideLength; i++)
                {
                    for (int j = 0; j < SideLength; j++)
                    {
                        Table[i, j] = SolvedTable[i, j];
                    }
                }

                EmptyCellsNum = 0;

                // removing cells and checking if it still has a unique solution
                for (int i, j, counter = 0; counter < 400 && EmptyCellsNum < EmptyCells[(int)difficulty]; counter++)
                {
                    i = new Random().Next(SideLength);
                    j = new Random().Next(SideLength);

                    if (Table[i, j] != 0)
                    {
                        Table[i, j] = 0;
                        int SolutionCounter = 0;
                        CountSolutions(ref SolutionCounter);
                        if (SolutionCounter == 1)
                            EmptyCellsNum++;
                        else
                            Table[i, j] = SolvedTable[i, j];
                    }
                }

                // not removing randomly anymore
                for (int i = 0; i < SideLength && EmptyCellsNum < EmptyCells[(int)difficulty]; i++)
                {
                    for (int j = 0; j < SideLength && EmptyCellsNum < EmptyCells[(int)difficulty]; j++)
                    {
                        if (Table[i, j] != 0)
                        {
                            Table[i, j] = 0;
                            int SolutionCounter = 0;
                            CountSolutions(ref SolutionCounter);
                            if (SolutionCounter == 1)
                                EmptyCellsNum++;
                            else
                                Table[i, j] = SolvedTable[i, j];
                        }
                    }
                }
            }

            for (int i = 0; i < SideLength; i++)
            {
                for (int j = 0; j < SideLength; j++)
                {
                    if (Table[i, j] != 0)
                    {
                        IsNative[i, j] = true; // numbers that belong to the table
                    }
                }
            }

            ShowTable();
        }

        private static void CreationMenu(out Difficulty difficulty)
        {
            Console.BackgroundColor = Background_Color;
            Console.Clear();

            Console.ForegroundColor = Text_Color;
            Console.Write("Welcome to the game of ");
            Console.ForegroundColor = Special_Color;
            Console.Write("SuDoKu");
            Console.ForegroundColor = Text_Color;
            Console.WriteLine("!\n");

            Console.WriteLine("Please Choose the difficulty: ");

            Console.ForegroundColor = Number_Color;
            Console.Write("1.");
            Console.ForegroundColor = Selection_Color;
            Console.WriteLine(Difficulty.Diffault);

            Console.ForegroundColor = Number_Color;
            Console.Write("2.");
            Console.ForegroundColor = Selection_Color;
            Console.WriteLine(Difficulty.Easy);

            Console.ForegroundColor = Number_Color;
            Console.Write("3.");
            Console.ForegroundColor = Selection_Color;
            Console.WriteLine(Difficulty.Normal);

            Console.ForegroundColor = Number_Color;
            Console.Write("4.");
            Console.ForegroundColor = Selection_Color;
            Console.WriteLine(Difficulty.Hard);

            while (true)
            {
                Console.ForegroundColor = User_Color;
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                    case "Diffault":
                    case "diffault":
                        difficulty = Difficulty.Diffault;
                        return;

                    case "2":
                    case "Easy":
                    case "easy":
                        difficulty = Difficulty.Easy;
                        return;

                    case "3":
                    case "Normal":
                    case "normal":
                        difficulty = Difficulty.Normal;
                        return;

                    case "4":
                    case "Hard":
                    case "hard":
                        difficulty = Difficulty.Hard;
                        return;
                }

                Console.ForegroundColor = Error_Color;
                Console.WriteLine("Invalid input!");
            }
        }

        public bool ShowMenu()
        {
            Console.WriteLine();

            string[] Menu = { "Add number",
                              "Delete",
                              "Hint",
                              "Show Table",
                              "Exit" };

            for (int n = 0; n < Menu.Length; n++)
            {
                Console.ForegroundColor = Number_Color;
                Console.Write(n + 1 + ".");
                Console.ForegroundColor = Selection_Color;
                Console.WriteLine(Menu[n]);
            }

            Console.ForegroundColor = User_Color;
            string selected = Console.ReadLine();

            int i, j, num;

            switch (selected)
            {
                case "1":
                case "Add number":
                case "add number":
                    Console.ForegroundColor = Text_Color;
                    Console.Write("Row: ");
                    Console.ForegroundColor = User_Color;
                    i = int.Parse(Console.ReadLine());

                    Console.ForegroundColor = Text_Color;
                    Console.Write("Column: ");
                    Console.ForegroundColor = User_Color;
                    j = int.Parse(Console.ReadLine());

                    Console.ForegroundColor = Text_Color;
                    Console.Write("Number: ");
                    Console.ForegroundColor = User_Color;
                    num = int.Parse(Console.ReadLine());

                    Add(i, j, ref num);
                    break;

                case "2":
                case "Delete":
                case "delete":
                    Console.ForegroundColor = Text_Color;
                    Console.Write("Row: ");
                    Console.ForegroundColor = User_Color;
                    i = int.Parse(Console.ReadLine());

                    Console.ForegroundColor = Text_Color;
                    Console.Write("Column: ");
                    Console.ForegroundColor = User_Color;
                    j = int.Parse(Console.ReadLine());

                    Delete(i, j);
                    break;

                case "3":
                case "Hint":
                case "hint":
                    Hint();
                    break;

                case "4":
                case "Show Table":
                case "show table":
                    ShowTable();
                    break;

                case "5":
                case "Exit":
                case "exit":
                    ShowResults();
                    Console.ResetColor();
                    return false;

                default:
                    Console.ForegroundColor = Error_Color;
                    Console.WriteLine("Invalid input!");
                    break;
            }

            if (EmptyCellsNum != 0)
                HasBeenShown = false;

            if (EmptyCellsNum == 0 && !HasBeenShown)
            {
                Console.ForegroundColor = Special_Color;

                if (IsSolved())
                {
                    Console.WriteLine("Congratulations! You have successfully completed the table :)\n");
                }
                else
                {
                    Console.WriteLine("The table is not solved correctly!\n");
                }
            }

            return true;
        }

        private void Add(int i, int j, ref int num)
        {
            i--; j--;

            if (i < 0 || j < 0 || i >= SideLength || j >= SideLength || num < 1 || num > SideLength)
            {
                Console.ForegroundColor = Error_Color;
                Console.WriteLine("Invalid input!");
            }
            else if (Table[i, j] != 0)
            {
                Console.ForegroundColor = Failure_Color;
                Console.WriteLine("Cell is already occupied by another number!");
            }
            else
            {
                Table[i, j] = num;
                EmptyCellsNum--;

                Console.ForegroundColor = Success_Color;
                Console.WriteLine("Number was successfully added.");
            }
        }

        private void Delete(int i, int j)
        {
            i--; j--;

            if (i < 0 || j < 0 || i >= SideLength || j >= SideLength)
            {
                Console.ForegroundColor = Error_Color;
                Console.WriteLine("Invalid input!");
            }
            else if (IsNative[i, j])
            {
                Console.ForegroundColor = Failure_Color;
                Console.WriteLine("Can't delete numbers that belong to the table!");
            }
            else if (Table[i, j] == 0)
            {
                Console.ForegroundColor = Failure_Color;
                Console.WriteLine("Cell is already empty!");
            }
            else
            {
                Table[i, j] = 0;
                EmptyCellsNum++;

                Console.ForegroundColor = Success_Color;
                Console.WriteLine("Number was successfully removed.");
            }
        }

        private void Hint()
        {
            if (NumberOfHints == 0)
            {
                Console.ForegroundColor = Failure_Color;
                Console.WriteLine("You have used up all your hints!");
            }
            else if (EmptyCellsNum < CellsToFill_ForEachHint)
            {
                Console.ForegroundColor = Failure_Color;
                Console.WriteLine("Can't add anymore numbers to the table!");
            }
            else
            {
                for (int hint = 1; hint <= CellsToFill_ForEachHint;)
                {
                    int i = new Random().Next(0, SideLength);
                    int j = new Random().Next(0, SideLength);

                    if (Table[i, j] == 0)
                    {
                        Table[i, j] = SolvedTable[i, j];
                        hint++;
                    }
                }

                Console.ForegroundColor = Special_Color;
                Console.Write(CellsToFill_ForEachHint);
                Console.ForegroundColor = Success_Color;
                Console.WriteLine(" numbers have been added to the table successfully");
                NumberOfHints--;
                EmptyCellsNum -= CellsToFill_ForEachHint;
            }
        }

        private void ShowTable()
        {
            ConsoleColor TableBackground_Color = ConsoleColor.DarkCyan;
            ConsoleColor BlocksBackground_Color = ConsoleColor.White;
            ConsoleColor Natives_Color = ConsoleColor.Black;
            ConsoleColor Added_Color = ConsoleColor.DarkBlue;

            int Width = SideLength * BlockLength + 2;
            const char EmptyCell = '.';

            Console.WriteLine();

            for (int i = 0; i < SideLength; i++)
            {
                if (i % BlockLength == 0) // space between rows
                {
                    Console.BackgroundColor = TableBackground_Color;
                    for (int w = 1; w <= Width; w++)
                    {
                        Console.Write(' ');
                    }

                    Console.BackgroundColor = Background_Color;
                    Console.WriteLine();
                }

                Console.BackgroundColor = TableBackground_Color;
                Console.Write("  ");

                for (int j = 0; j < SideLength; j++)
                {
                    Console.BackgroundColor = BlocksBackground_Color;
                    Console.Write(' ');

                    if (j % BlockLength == 0 && j != 0) // space between columns
                    {
                        Console.BackgroundColor = TableBackground_Color;
                        Console.Write("  ");
                        Console.BackgroundColor = BlocksBackground_Color;
                        Console.Write(' ');
                    }

                    Console.ForegroundColor = Natives_Color;

                    if (Table[i, j] == 0)
                    {
                        Console.Write(EmptyCell);
                    }
                    else
                    {
                        if (!IsNative[i, j])
                        {
                            Console.ForegroundColor = Added_Color;
                        }

                        Console.Write(Table[i, j]);
                    }
                }

                Console.BackgroundColor = BlocksBackground_Color;
                Console.Write(' ');
                Console.BackgroundColor = TableBackground_Color;
                Console.Write("  ");
                Console.BackgroundColor = Background_Color;
                Console.WriteLine();
            }

            Console.BackgroundColor = TableBackground_Color;
            for (int w = 1; w <= Width; w++)
            {
                Console.Write(' ');
            }

            Console.BackgroundColor = Background_Color;
            Console.WriteLine();
        }

        private void ShowResults()
        {
            Console.WriteLine();

            Console.ForegroundColor = Text_Color;
            Console.Write("Filled cells: ");
            Console.ForegroundColor = Special_Color;
            Console.WriteLine(SideLength * SideLength - EmptyCellsNum);

            Console.ForegroundColor = Text_Color;
            Console.Write("Remaining: ");
            Console.ForegroundColor = Special_Color;
            Console.WriteLine(EmptyCellsNum);
        }

        private bool IsSolved()
        {
            for (int i = 0; i < SideLength; i++)
            {
                for (int j = 0; j < SideLength; j++)
                {
                    if (SolvedTable[i, j] != Table[i, j])
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private void Shuffle() // shuffles the numberlist
        {
            int i, j, tmp;
            for (int slots = SideLength; slots > 0; slots--)
            {
                i = new Random().Next(SideLength);
                j = new Random().Next(SideLength);
                tmp = NumbersList[i];
                NumbersList[i] = NumbersList[j];
                NumbersList[j] = tmp;
            }
        }

        private bool Solve(int i = 0, int j = 0)
        {
            if (i == SideLength - 1 && j == SideLength)
            {
                return true;
            }

            if (j == SideLength)
            {
                i++; j = 0;
            }

            if (Table[i, j] != 0)
            {
                return Solve(i, j + 1);
            }

            for (int index = 0; index < SideLength; index++)
            {
                int num = NumbersList[index]; // the list is shuffled so the generated tables are different

                if (IsRowSafe(ref i, ref num) && IsColumnSafe(ref j, ref num) && IsBlockSafe(ref i, ref j, ref num))
                {
                    Table[i, j] = num;

                    if (Solve(i, j + 1))
                    {
                        SolvedTable[i, j] = num;
                        Table[i, j] = 0;
                        return true;
                    }

                    Table[i, j] = 0;
                }
            }

            return false;
        }

        private void CountSolutions(ref int SolutionCounter, int i = 0, int j = 0)
        {
            if (SolutionCounter > 1)
                return;

            if (i == SideLength - 1 && j == SideLength)
            {
                SolutionCounter++;
                return;
            }

            if (j == SideLength)
            {
                i++; j = 0;
            }

            if (Table[i, j] != 0)
            {
                CountSolutions(ref SolutionCounter, i, j + 1);
                return;
            }

            for (int num = 1; num <= SideLength; num++)
            {
                if (IsRowSafe(ref i, ref num) && IsColumnSafe(ref j, ref num) && IsBlockSafe(ref i, ref j, ref num))
                {
                    Table[i, j] = num;

                    CountSolutions(ref SolutionCounter, i, j + 1);

                    Table[i, j] = 0;
                }
            }
        }

        private bool IsRowSafe(ref int i, ref int num)
        {
            for (int j = 0; j < SideLength; j++)
                if (Table[i, j] == num)
                    return false;

            return true;
        }

        private bool IsColumnSafe(ref int j, ref int num)
        {
            for (int i = 0; i < SideLength; i++)
                if (Table[i, j] == num)
                    return false;

            return true;
        }

        private bool IsBlockSafe(ref int row, ref int column, ref int num)
        {
            int i = row - row % BlockLength;

            do
            {
                int j = column - column % BlockLength;

                do
                {
                    if (Table[i, j] == num)
                        return false;

                    j++;
                } while (j % BlockLength != 0);

                i++;
            } while (i % BlockLength != 0);

            return true;
        }
    }
}