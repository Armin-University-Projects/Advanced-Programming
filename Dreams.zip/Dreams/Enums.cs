﻿namespace Dreams
{
    public enum AccessType
    {
        Admin,
        User
    }
}
