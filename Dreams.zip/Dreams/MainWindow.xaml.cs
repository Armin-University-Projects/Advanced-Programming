﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Dreams
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        static MainWindow()
        {
            InitializeAll();
        }

        private void Exit_Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Maximize_Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Maximized)
            {
                this.WindowState = WindowState.Normal;
            }
            else
            {
                this.WindowState = WindowState.Maximized;
            }
        }

        private void Minimize_Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Admin_Option_Click(object sender, RoutedEventArgs e)
        {
            SignInWindow signInWindow= new(nameof(Seller));
            signInWindow.Show();
            this.Close();
        }

        private void User_Option_Click(object sender, RoutedEventArgs e)
        {
            Welcome_Page.Visibility = Visibility.Hidden;
            UserType_Selection.Visibility = Visibility.Visible;
        }

        private void Student_Option_Click(object sender, RoutedEventArgs e)
        {
            SignInWindow signInWindow = new(nameof(Student));
            signInWindow.Show();
            this.Close();
        }

        private void Teacher_Option_Click(object sender, RoutedEventArgs e)
        {
            SignInWindow signInWindow = new(nameof(Teacher));
            signInWindow.Show();
            this.Close();
        }

        private void Customer_Option_Click(object sender, RoutedEventArgs e)
        {
            SignInWindow signInWindow = new(nameof(Customer));
            signInWindow.Show();
            this.Close();
        }

        private void Return_Option_Click(object sender, RoutedEventArgs e)
        {
            UserType_Selection.Visibility = Visibility.Hidden;
            Welcome_Page.Visibility = Visibility.Visible;   
        }

        private static void InitializeAll()
        {
            Student.Initialize();
            Teacher.Initialize();
            Customer.Initialize();
            Book.Initialize();
            Video.Initialize();
            Magazine.Initialize();
        }
    }
}
