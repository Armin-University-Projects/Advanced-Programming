﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Dreams
{
    public partial class SellerWindow : Window
    {
        public static ObservableCollection<Buyer> Customers { get; set; }
        private string? MediaToAdd;

        private readonly Seller seller;
        public SellerWindow(Seller seller)
        {
            DataContext = this;
            this.seller = seller;
            InitializeComponent();
        }

        static SellerWindow()
        {
            Customers = new();
        }

        private void Exit_Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new();
            mainWindow.Show();
            this.Close();
        }

        private void Maximize_Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Maximized)
            {
                this.WindowState = WindowState.Normal;
            }
            else
            {
                this.WindowState = WindowState.Maximized;
            }
        }

        private void Minimize_Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Book_Option_Click(object sender, RoutedEventArgs e)
        {
            ((TextBlock)Fields.Children[6]).Text = "Writer";
            ((TextBlock)Fields.Children[8]).Text = "Publisher";

            MediaToAdd = nameof(Book);

            AdditionTab.Visibility = Visibility.Visible;
        }

        private void Video_Option_Click(object sender, RoutedEventArgs e)
        {
            ((TextBlock)Fields.Children[6]).Text = "Duration";
            ((TextBlock)Fields.Children[8]).Text = "Number of DVDs";

            MediaToAdd = nameof(Video);

            AdditionTab.Visibility = Visibility.Visible;
        }

        private void Magazine_Option_Click(object sender, RoutedEventArgs e)
        {
            ((TextBlock)Fields.Children[6]).Text = "Publisher";
            ((TextBlock)Fields.Children[8]).Text = "Number of Pages";

            MediaToAdd = nameof(Magazine);

            AdditionTab.Visibility = Visibility.Visible;
        }

        private void Addition_Option_Click(object sender, RoutedEventArgs e)
        {
            if (MediaToAdd == nameof(Book))
            {
                Book.Add(((TextBox)Fields.Children[1]).Text, ((TextBox)Fields.Children[3]).Text, ((TextBox)Fields.Children[5]).Text, ((TextBox)Fields.Children[7]).Text, ((TextBox)Fields.Children[9]).Text);
            }
            else if (MediaToAdd == nameof(Video))
            {
                Video.Add(((TextBox)Fields.Children[1]).Text, ((TextBox)Fields.Children[3]).Text, ((TextBox)Fields.Children[5]).Text, ((TextBox)Fields.Children[7]).Text, ((TextBox)Fields.Children[9]).Text);
            }
            else if (MediaToAdd == nameof(Magazine))
            {
                Magazine.Add(((TextBox)Fields.Children[1]).Text, ((TextBox)Fields.Children[3]).Text, ((TextBox)Fields.Children[5]).Text, ((TextBox)Fields.Children[7]).Text, ((TextBox)Fields.Children[9]).Text);
            }

            AdditionTab.Visibility = Visibility.Hidden;
        }

        private void DeleteProduct_Option_Click(object sender, RoutedEventArgs e)
        {
            if (ulong.TryParse(DeleteBox.Text, out ulong id))
            {
                Library.DelMedia(id);
            }
        }

        private void SearchProduct_Option_Click(object sender, RoutedEventArgs e)
        {
            if (ulong.TryParse(SearchBox.Text, out ulong id))
            {
                Library.SearchMedia(id);
            }
        }

        private void ChangePass_Option_Click(object sender, RoutedEventArgs e)
        {
            if (seller.ChangePassword(newPassBox.Text))
            {
                Time.Text = DateTime.Now.ToString();
            }
        }
    }
}
