﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows;

namespace Dreams
{
    public static class Library
    {
        public static List<Media> MediaList { get; private set; }

        static Library()
        {
            MediaList = new();
        }

        public static void DelMedia(ulong mediaToDelete_ID)
        {
            for (int i = MediaList.Count - 1; i > 0; i--)
            {
                if (MediaList[i].ID == mediaToDelete_ID)
                {
                    if (MediaList[i] is Book)
                    {
                        MediaList.RemoveAt(i);
                        Book.Update();
                    }
                    else if (MediaList[i] is Video)
                    {
                        MediaList.RemoveAt(i);
                        Video.Update();
                    }
                    else if (MediaList[i] is Magazine)
                    {
                        MediaList.RemoveAt(i);
                        Magazine.Update();
                    }

                    MessageBox.Show($"Product was successfully deleted");
                    return;
                }
            }

            MessageBox.Show(new ObjectNotFoundException("product", "ID").Message);
        }

        public static void SearchMedia(ulong mediaToFind_ID)
        {
            foreach(Media media in MediaList)
            {
                if (media.ID == mediaToFind_ID)
                {
                    MessageBox.Show(InfoToString(media));
                    return;
                }
            }

            MessageBox.Show(new ObjectNotFoundException("Product", "ID").Message);
        }

        public static string InfoToString(Media media)
        {
            if (media is Book book)
            {
                return book.ToString();
            }
            else if (media is Video video)
            {
                return video.ToString();
            }
            else if (media is Magazine magazine)
            {
                return magazine.ToString();
            }
            else
            {
                return media.ToString();
            }
        }
    }
}
