﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows;

namespace Dreams
{
    public class Seller : IPerson
    {
        private static readonly List<Seller> SellersList;

        public AccessType AccessType
        {
            get => AccessType.Admin;
        }

        private string Email;
        public string Username
        {
            get => Email;
            protected set
            {
                if (value.IsValidEmail())
                {
                    Email = value;
                }
            }
        }

        private string _Password;
        protected string Password
        {
            get => _Password;
            private set => _Password = value;
        }

        public Seller(string email, string password)
        {
            if (!email.IsValidEmail())
            {
                throw new NotValidException("email address");
            }

            if (!password.IsValidPassword())
            {
                throw new NotValidException(nameof(password));
            }

            this.Email = email;
            this._Password = password;
            SellersList.Add(this);
        }

        static Seller()
        {
            SellersList = new();
        }

        public static Seller SignIn(string username, string password)
        {
            if (!username.IsValidEmail())
            {
                throw new NotValidException("email address");
            }

            if (!password.IsValidPassword())
            {
                throw new NotValidException(nameof(password));
            }

            const string DefaultPassword = "MyShop1234$";

            Seller? seller = Find(username);

            if (seller is null && password == DefaultPassword)
            {
                return new Seller(username, DefaultPassword);
            }

            if (seller != null && seller.Password == password)
            {
                return seller;
            }

            throw new Exception("Wrong password!");
        }

        private static Seller? Find(string username)
        {
            foreach (Seller seller in SellersList)
            {
                if (seller.Username == username)
                {
                    return seller;
                }
            }

            return null;
        }

        public bool ChangePassword(string newPass)
        { 
            if (newPass.IsValidPassword())
            {
                if (newPass == this.Password)
                {
                    MessageBox.Show("New Password can't be the same as the old one!");
                    return false;
                }

                this.Password = newPass;
                return true;
            }

            MessageBox.Show(new NotValidException(nameof(Password)).Message);
            return false;
        }
    }
}
