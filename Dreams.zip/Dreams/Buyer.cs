﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows;

namespace Dreams
{
    public abstract class Buyer : IPerson
    {
        public AccessType AccessType
        {
            get => AccessType.User;
        }

        private string Name;
        public string Username
        {
            get => Name;
            protected set
            {
                if (value.IsValidName())
                {
                    Name = value;
                }
            }
        }

        public const uint MaximumBuy = 20;

        protected Buyer(string name)
        {
            if (!name.IsValidName())
            {
                throw new NotValidException(nameof(name));
            }

            this.Name = name;
            this.BuyList = new();
            this.Discounts = new();
            BuyInfo = "";
        }

        public string BuyInfo { get; private set; }

        public List<Media> BuyList { get; set; }

        public void AddToBuyList(ulong ProductID)
        {
            foreach (Media media in Library.MediaList)
            {
                if (media.ID == ProductID && !ItemExists(ProductID))
                {
                    this.BuyList.Add(media);
                    BuyInfo = "";
                    uint Total = 0;
                    foreach (Media _media in BuyList)
                    {
                        Total += CountPrice(_media);
                        BuyInfo += _media.BuyInfo + $"\tFinal Price: {CountPrice(_media)}\n";
                    }
                    BuyInfo += $"Total: {Total}";
                    MessageBox.Show("Item was successfully added");
                    return;
                }
            }

            MessageBox.Show(new ObjectNotFoundException("Product", "ID").Message);
        }

        private bool ItemExists(ulong id)
        {
            foreach (Media media in BuyList)
            {
                if (media.ID == id)
                {
                    return true;
                }
            }

            return false;
        }

        public void DeleteFromBuyList(ulong ProductID)
        {
            for (int i = BuyList.Count - 1; i >= 0; i--)
            {
                if (BuyList[i].ID == ProductID)
                {
                    BuyList.RemoveAt(i);
                    BuyInfo = "";
                    uint Total = 0;
                    foreach (Media _media in BuyList)
                    {
                        Total += CountPrice(_media);
                        BuyInfo += _media.BuyInfo + $"\tFinal Price: {CountPrice(_media)}\n";
                    }
                    BuyInfo += $"Total: {Total}";
                    MessageBox.Show("Item was successfully deleted");
                    return;
                }
            }

            MessageBox.Show(new ObjectNotFoundException("Product", "ID").Message);
        }

        public abstract Discount Discount { get; protected set; }
        public List<Discount> Discounts;

        public virtual uint CountPrice(Media media)
        {
            if (this is Student student)
            {
                return student.CountPrice(media);
            }
            else if (this is Teacher teacher)
            {
                return teacher.CountPrice(media);
            }
            else if (this is Customer customer)
            {
                return customer.CountPrice(media);
            }
            else
            {
                return this.CountPrice(media);
            }
        }
    }

    public class Student : Buyer
    {
        public static readonly List<Student> StudentsList;

        private string StudentID;
        protected string Password
        {
            get => StudentID;
            private set => StudentID = value;
        }

        public override Discount Discount { get; protected set; }

        private const string FilePath = @"Students Info.txt";

        public Student(string name, string studentID)
            : base(name)
        {
            if (!studentID.IsValidStudentID())
            {
                throw new NotValidException("student ID");
            }
            
            this.StudentID = studentID;
            this.Discount = new(20, 0);
            this.Discounts.Add(this.Discount);
        }

        static Student()
        {
            StudentsList = new();
        }

        public static void Initialize()
        {
            if (!File.Exists(FilePath))
            {
                FileStream fileStream = File.Create(FilePath);
                fileStream.Close();
                return;
            }

            string[] allInfo = File.ReadAllLines(FilePath);
            for (int i = 0; i < allInfo.Length; )
            {
                Student student = new(allInfo[i++].Decode(), allInfo[i++].Decode());
                StudentsList.Add(student);
                SellerWindow.Customers.Add(student);
            }
        }

        public static Student SignIn(string name, string studentID)
        {
            if (!name.IsValidName())
            {
                throw new NotValidException(nameof(name));
            }

            if (!studentID.IsValidStudentID())
            {
                throw new NotValidException("student ID");
            }

            Student? student = Find(studentID);

            if (student == null)
            {
                Student newStudent = new(name, studentID);
                newStudent.AddToFile();
                SellerWindow.Customers.Add(newStudent);
                return newStudent;
            }

            if (student.Username == name)
            {
                return student;
            }

            throw new Exception("Wrong name!");
        }

        private static Student? Find(string studentID)
        {
            foreach (Student student in StudentsList)
            {
                if (student.StudentID == studentID)
                {
                    return student;
                }
            }

            return null;
        }

        protected void AddToFile()
        {
            using StreamWriter streamWriter = new(FilePath, true);
            streamWriter.WriteLine(this.Username.Encode());
            streamWriter.WriteLine(this.Password.Encode());
        }

        public override uint CountPrice(Media media)
        {
            uint sub = 0;
            foreach (Discount discount in Discounts)
            {
                if (BuyList.Count > discount.BuyesNum)
                {
                    sub += discount.value;
                }
            }

            uint priceToSub = (media.Price * sub) / 100;

            if (media is Book book)
            {
                return book.CountTaxes() - priceToSub;
            }
            else if (media is Video video)
            {
                return video.CountTaxes() - priceToSub;
            }
            else if (media is Magazine magazine)
            {
                return magazine.CountTaxes() - priceToSub;
            }

            return media.Price;
        }
    }

    public class Teacher : Buyer
    {
        public static readonly List<Teacher> TeachersList;

        private string Institution;
        protected string Password
        {
            get => Institution;
            private set => Institution = value;
        }

        public override Discount Discount { get; protected set; }

        private const string FilePath = @"Teachers Info.txt";

        public Teacher(string name, string institution)
            : base(name)
        {
            if (!institution.IsValidInstitution())
            {
                throw new NotValidException("student ID");
            }

            this.Institution = institution;
            this.Discount = new(15, 3);
            this.Discounts.Add(this.Discount);
        }

        static Teacher()
        {
            TeachersList = new();
        }

        public static void Initialize()
        {
            if (!File.Exists(FilePath))
            {
                FileStream fileStream = File.Create(FilePath);
                fileStream.Close();
                return;
            }

            string[] allInfo = File.ReadAllLines(FilePath);
            for (int i = 0; i < allInfo.Length; )
            {
                Teacher teacher = new(allInfo[i++].Decode(), allInfo[i++].Decode());
                TeachersList.Add(teacher);
                SellerWindow.Customers.Add(teacher);
            }
        }

        public static Teacher SignIn(string name, string institution)
        {
            if (!name.IsValidName())
            {
                throw new NotValidException(nameof(name));
            }

            if (!institution.IsValidInstitution())
            {
                throw new NotValidException(nameof(institution));
            }

            Teacher teacher = new(name, institution);
            teacher.AddToFile();
            SellerWindow.Customers.Add(teacher);
            return teacher;
        }

        protected void AddToFile()
        {
            using StreamWriter streamWriter = new(FilePath, true);
            streamWriter.WriteLine(this.Username.Encode());
            streamWriter.WriteLine(this.Password.Encode());
        }

        public override uint CountPrice(Media media)
        {
            uint sub = 0;
            foreach (Discount discount in Discounts)
            {
                if (BuyList.Count > discount.BuyesNum)
                {
                    sub += discount.value;
                }
            }

            uint priceToSub = (media.Price * sub) / 100;

            if (media is Book book)
            {
                return book.CountTaxes() - priceToSub;
            }
            else if (media is Video video)
            {
                return video.CountTaxes() - priceToSub;
            }
            else if (media is Magazine magazine)
            {
                return magazine.CountTaxes() - priceToSub;
            }

            return media.Price;
        }
    }

    public class Customer : Buyer
    {
        public static readonly List<Customer> CustomersList;

        private string SSN;
        protected string Password
        {
            get => SSN;
            private set => SSN = value;
        }
        public override Discount Discount { get; protected set; }

        private const string FilePath = @"Customers Info.txt";

        public Customer(string name, string ssn)
            : base(name)
        {
            if (!ssn.IsValidSSN())
            {
                throw new NotValidException("student ID");
            }

            this.SSN = ssn;
            this.Discount = new(5, 5);
            this.Discounts.Add(this.Discount);
        }

        static Customer()
        {
            CustomersList = new();
        }

        public static void Initialize()
        {
            if (!File.Exists(FilePath))
            {
                FileStream fileStream = File.Create(FilePath);
                fileStream.Close();
                return;
            }

            string[] allInfo = File.ReadAllLines(FilePath);
            for (int i = 0; i < allInfo.Length; )
            {
                Customer customer = new(allInfo[i++].Decode(), allInfo[i++].Decode());
                Customer.CustomersList.Add(customer);
                SellerWindow.Customers.Add(customer);
            }
        }

        public static Customer SignIn(string name, string ssn)
        {
            if (!name.IsValidName())
            {
                throw new NotValidException(nameof(name));
            }

            if (!ssn.IsValidSSN())
            {
                throw new NotValidException(nameof(SSN));
            }

            Customer? customer = Find(ssn);

            if (customer is null)
            {
                Customer newCustomer = new(name, ssn);
                newCustomer.AddToFile();
                SellerWindow.Customers.Add(newCustomer);
                return newCustomer;
            }

            if (customer.Username == name)
            {
                return customer;
            }

            throw new Exception("Wrong name!");
        }

        private static Customer? Find(string ssn)
        {
            foreach (Customer customer in CustomersList)
            {
                if (customer.SSN == ssn)
                {
                    return customer;
                }
            }

            return null;
        }

        protected void AddToFile()
        {
            using StreamWriter streamWriter = new(FilePath, true);
            streamWriter.WriteLine(this.Username.Encode());
            streamWriter.WriteLine(this.Password.Encode());
        }

        public override uint CountPrice(Media media)
        {
            uint sub = 0;
            foreach (Discount discount in Discounts)
            {
                if (BuyList.Count > discount.BuyesNum)
                {
                    sub += discount.value;
                }
            }

            uint priceToSub = (media.Price * sub) / 100;

            if (media is Book book)
            {
                return book.CountTaxes() - priceToSub;
            }
            else if (media is Video video)
            {
                return video.CountTaxes() - priceToSub;
            }
            else if (media is Magazine magazine)
            {
                return magazine.CountTaxes() - priceToSub;
            }

            return media.Price;
        }
    }
}
