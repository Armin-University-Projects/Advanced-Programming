﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;

namespace Dreams
{
    public abstract class Media : IProduct
    {
        private readonly string _Title;
        public string Title
        {
            get => _Title;
        }

        private uint _Price;
        public uint Price
        {
            get => _Price;
            protected set => _Price = value;
        }

        private readonly ulong _ID;
        public ulong ID
        {
            get => _ID;
        }

        public string Info { get; protected set; }

        public string BuyInfo 
        {
            get => $"Title: {Title}\tID: {ID}\tOriginal Price: {Price}\tTaxed Price: {CountTaxes()}";
        }

        protected Media(ulong id, string title, uint price)
        {
            _Title = title;
            Price = price; ;
            _ID = id;
            Info = "";
            Library.MediaList.Add(this);
            BuyerWindow.Products.Add(this);
        }

        public abstract uint CountTaxes();

        public override string ToString()
            => $"ID: {this.ID}\n"
             + $"Title: {this.Title}\n"
             + $"Price: {this.Price}";
    }

    public class Book : Media ,IBook
    {
        private readonly string _Writer;
        public string Writer
        {
            get => _Writer;
        }

        private readonly string _Publisher;
        public string Publisher 
        { 
            get => _Publisher;
        }

        private const string FilePath = @"Books Info.txt";

        public Book(ulong id, string title, uint price, string writer, string publisher)
            : base(id, title, price)
        {
            this._Writer = writer;
            this._Publisher = publisher;
            this.Info += this.ToString() + "\n";
        }

        public static void Initialize()
        {
            if (!File.Exists(FilePath))
            {
                FileStream fileStream = File.Create(FilePath);
                fileStream.Close();
                return;
            }

            string[] allInfo = File.ReadAllLines(FilePath);
            for (int i = 0; i < allInfo.Length; )
            {
                string[] info = new string[5];
                info[0] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[1] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[2] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[3] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[4] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];

                new Book(ulong.Parse(info[0]), info[1], uint.Parse(info[2]), info[3], info[4]);
            }
        }

        public static void Add(string id, string title, string price, string writer, string publisher)
        {
            if (!ulong .TryParse(id, out ulong ID) || !uint.TryParse(price, out uint Price))
            {
                MessageBox.Show(new NotValidException("Information").Message);
                return;
            }

            foreach (Media media in Library.MediaList)
            {
                if (media.ID == ID)
                {
                    MessageBox.Show(new ObjectExistsException("Product", "ID").Message);
                    return;
                }
            }

            new Book(ID, title, Price, writer, publisher).AddToFile();
            MessageBox.Show("Item was successfully added");
        }

        public void AddToFile()
        {
            using StreamWriter streamWriter = new(FilePath, true);
            streamWriter.WriteLine(this.ToString());
        }

        public static void Update()
        {
            File.WriteAllText(FilePath, String.Empty);
            foreach (Media media in Library.MediaList)
            {
                if (media is Book book)
                {
                    book.AddToFile();
                }
            }
        }

        public override uint CountTaxes() => (this.Price * 110) / 100;

        public override string ToString()
            => $"{base.ToString()}\n"
             + $"Writer: {this.Writer}\n"
             + $"Publisher: {this.Publisher}";
    }

    public class Video : Media, IVideo
    {
        private uint _DVDsNum; 
        public uint DVDsNum
        {
            get => _DVDsNum;
            protected set => _DVDsNum = value;
        }

        private uint _Duration;
        public uint Duration
        {
            get => _Duration;
            protected set => _Duration = value;
        }

        private const string FilePath = @"Video Info.txt";

        public Video(ulong id, string title, uint price, uint duration, uint dvdsNum)
            : base(id, title, price)
        {
            this.DVDsNum = dvdsNum;
            this._Duration = duration;
            this.Info += this.ToString() + "\n";
        }

        public static void Initialize()
        {
            if (!File.Exists(FilePath))
            {
                FileStream fileStream = File.Create(FilePath);
                fileStream.Close();
                return;
            }

            string[] allInfo = File.ReadAllLines(FilePath);
            for (int i = 0; i < allInfo.Length;)
            {
                string[] info = new string[5];
                info[0] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[1] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[2] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[3] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[4] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];

                new Video(ulong.Parse(info[0]), info[1], uint.Parse(info[2]), uint.Parse(info[3]), uint.Parse(info[4]));
            }
        }

        public static void Add(string id, string title, string price, string duration, string dvdsNum)
        {
            if (!ulong.TryParse(id, out ulong ID) || !uint.TryParse(price, out uint Price) || !uint.TryParse(duration, out uint Duration) || !uint.TryParse(dvdsNum, out uint DVDsNum))
            {
                MessageBox.Show(new NotValidException("Information").Message);
                return;
            }

            foreach (Media media in Library.MediaList)
            {
                if (media.ID == ID)
                {
                    MessageBox.Show(new ObjectExistsException("Product", "ID").Message);
                    return;
                }
            }

            new Video(ID, title, Price, Duration, DVDsNum).AddToFile();
            MessageBox.Show("Item was successfully added");
        }

        public void AddToFile()
        {
            using StreamWriter streamWriter = new(FilePath, true);
            streamWriter.WriteLine(this.ToString());
        }

        public static void Update()
        {
            File.WriteAllText(FilePath, String.Empty);
            foreach (Media media in Library.MediaList)
            {
                if (media is Video video)
                {
                    video.AddToFile();
                }
            }
        }

        public override uint CountTaxes()
        {
            uint extra = (Duration / 60) * 5 + DVDsNum * 3;

            return this.Price * (100 + extra) / 100;
        }

        public override string ToString()
            => $"{base.ToString()}\n"
             + $"Duration: {this.Duration}\n"
             + $"Number of DVDs: {this.DVDsNum}";
    }

    public class Magazine : Media, IMagazine
    {
        private readonly uint _PagesNum;
        public uint PagesNum
        {
            get => _PagesNum;
        }

        private readonly string _Publisher;
        public string Publisher
        {
            get => _Publisher;
        }

        private const string FilePath = @"Magazines Info.txt";

        public Magazine(ulong id, string title, uint price, string publisher, uint pagesNum)
            : base(id, title, price)
        {
            this._PagesNum = pagesNum;
            this._Publisher = publisher;
            this.Info += this.ToString() + "\n";
        }

        public static void Initialize()
        {
            if (!File.Exists(FilePath))
            {
                FileStream fileStream = File.Create(FilePath);
                fileStream.Close();
                return;
            }

            string[] allInfo = File.ReadAllLines(FilePath);
            for (int i = 0; i < allInfo.Length; )
            {
                string[] info = new string[5];
                info[0] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[1] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[2] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[3] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];
                info[4] = allInfo[i][(allInfo[i++].IndexOf(':') + 2)..];

                new Magazine(ulong.Parse(info[0]), info[1], uint.Parse(info[2]), info[3], uint.Parse(info[4]));
            }
        }

        public static void Add(string id, string title, string price, string pagesNum, string publisher)
        {
            if (!ulong.TryParse(id, out ulong ID) || !uint.TryParse(price, out uint Price) || !uint.TryParse(pagesNum, out uint PagesNum))
            {
                MessageBox.Show(new NotValidException("Information").Message);
                return;
            }

            foreach (Media media in Library.MediaList)
            {
                if (media.ID == ID)
                {
                    MessageBox.Show(new ObjectExistsException("Product", "ID").Message);
                    return;
                }
            }

            new Magazine(ID, title, Price, publisher, PagesNum).AddToFile();
            MessageBox.Show("Item was successfully added");
        }

        public void AddToFile()
        {
            using StreamWriter streamWriter = new(FilePath, true);
            streamWriter.WriteLine(this.ToString());
        }

        public static void Update()
        {
            File.WriteAllText(FilePath, String.Empty);
            foreach (Media media in Library.MediaList)
            {
                if (media is Magazine magazine)
                {
                    magazine.AddToFile();
                }
            }
        }

        public override uint CountTaxes()
        {
            uint extra;

            if (this.PagesNum <= 20)
            {
                extra = 2;
            }
            else if (this.PagesNum <= 50)
            {
                extra = 3;
            }
            else
            {
                extra = 5;
            }

            return this.Price * (100 + extra) / 100;
        }

        public override string ToString()
            => $"{base.ToString()}\n"
             + $"Publisher: {this.Publisher}\n"
             + $"Number of Pages: {this.PagesNum}";
    }
}
