﻿namespace Dreams
{
    public interface IPerson
    {
        AccessType AccessType { get; }
        string Username { get; }
    }

    public interface IProduct
    {
        string Title { get; }
        uint Price { get; }
        ulong ID { get; }
        uint CountTaxes();
    }

    public interface IWriting
    {
        string Publisher { get; }
    }

    public interface IBook : IWriting
    {
        string Writer { get; }
    }

    public interface IVideo
    {
        uint Duration { get; }
    }

    public interface IMagazine : IWriting
    {
        uint PagesNum { get; }
    }
}
