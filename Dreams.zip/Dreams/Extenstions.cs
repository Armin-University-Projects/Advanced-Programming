﻿using System;
using System.Text.RegularExpressions;

namespace Dreams
{
    public static class Extentions
    {
        public static bool IsValidName(this string Name)
        {
            const string Name_Pattern = @"^[A-Z][a-z]{1,} [A-Z][a-z]{1,}";
            return Regex.IsMatch(Name, Name_Pattern);   
        }

        public static bool IsValidEmail(this string Email)
        {
            const string Email_Pattern = @"^\w{1,}@[a-zA-Z]{1,}\.[a-zA-Z]{1,}$";
            return Regex.IsMatch(Email, Email_Pattern);
        }

        public static bool IsValidStudentID(this string StudentID)
        {
            const string StudentID_Pattern = @"^9\d{7}$";
            return Regex.IsMatch(StudentID, StudentID_Pattern);
        }

        public static bool IsValidSSN(this string SSN)
        {
            const string SSN_Pattern = @"^\d{10}$";

            if (!Regex.IsMatch(SSN, SSN_Pattern))
            {
                return false;
            }

            bool hasNonDuplicate = false;
            for (int i = 0; i < SSN.Length; i++)
            {
                if (SSN[i] != SSN[++i])
                {
                    hasNonDuplicate = true;
                }
            }
            if (!hasNonDuplicate)
            {
                return false;
            }

            uint a, b = 0, c;

            a = (uint)SSN[^1];

            for (int i = 0; i < SSN.Length - 1; i++)
            {
                b += (uint)(SSN[i] - '0') * (uint)(SSN.Length - i);
            }

            c = b % 11;

            if ((a == c && (a == 0 || a == 1)))
            {
                return true;
            }

            if (c > 1 && a == Math.Abs(c - 11))
            {
                return true;
            }

            return false;
        }

        public static bool IsValidInstitution(this string Institution)
        {
            const string Institution_Pattern = @"^[a-z A-Z]{1,}$";
            return Regex.IsMatch(Institution, Institution_Pattern);
        }

        public static bool IsValidPassword(this string Password)
        {
            const string SmallCharacters = @"[a-z]";
            const string CapitalCharacters = @"[A-Z]";
            const string Digits = @"\d";
            return Regex.IsMatch(Password, SmallCharacters) && Regex.IsMatch(CapitalCharacters, CapitalCharacters) && Regex.IsMatch(Password, Digits);
        }

        public static string Encode(this string plainText)
        {
            byte[] plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Decode(this string encodedData)
        {
            byte[] encodedBytes = System.Convert.FromBase64String(encodedData);
            return System.Text.Encoding.UTF8.GetString(encodedBytes);
        }
    }
}
