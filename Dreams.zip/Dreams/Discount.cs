﻿using System;

namespace Dreams
{
    public struct Discount
    {
        public uint value;
        public int BuyesNum;

        public Discount(uint value, int BuyesNum)
        {
            this.value = value;
            this.BuyesNum = BuyesNum;
        }
    }
}
