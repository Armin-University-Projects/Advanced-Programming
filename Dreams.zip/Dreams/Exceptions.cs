﻿using System;

namespace Dreams
{
    public class NotValidException : Exception
    {
        public NotValidException(string paramName)
        : base($"Invalid {paramName}!") { }
    }

    public class ObjectNotFoundException : Exception
    {
        public ObjectNotFoundException(string objectName, string information)
        : base($"No {objectName} by this {information} exists!") { }
    }

    public class ObjectExistsException : Exception
    {
        public ObjectExistsException(string objectName, string information)
            : base($"{objectName} by this {information} already exists!") { }
    }
}
