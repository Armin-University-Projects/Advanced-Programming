﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Dreams
{
    public partial class BuyerWindow : Window
    {
        private readonly Buyer buyer;
        private bool hasUsedChance;
        public static ObservableCollection<Media> Products { get; set; }

        public BuyerWindow(Buyer buyer)
        {
            DataContext = this;
            this.hasUsedChance = false;
            this.buyer = buyer;
            InitializeComponent();
        }

        static BuyerWindow()
        {
            Products = new();
        }

        private void Exit_Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new();
            mainWindow.Show();
            this.Close();
        }

        private void Maximize_Button_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Maximized)
            {
                this.WindowState = WindowState.Normal;
            }
            else
            {
                this.WindowState = WindowState.Maximized;
            }
        }

        private void Minimize_Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Select_Option_Click(object sender, RoutedEventArgs e)
        {
            if (ulong.TryParse(SelectBox.Text, out ulong id))
            {
                buyer.AddToBuyList(id);
                Buy_List.Text = buyer.BuyInfo;
            }
        }

        private void Delete_Option_Click(object sender, RoutedEventArgs e)
        {
            if (ulong.TryParse(DeleteBox.Text, out ulong id))
            {
                buyer.DeleteFromBuyList(id);
                Buy_List.Text = buyer.BuyInfo;
            }
        }

        private void Buy_Option_Click(object sender, RoutedEventArgs e)
        {
            buyer.BuyList.Clear();
            MessageBox.Show("You have successfully bought evrything without paying anything :)");
        }

        private void Chance_Option_Click(object sender, RoutedEventArgs e)
        {
            if (hasUsedChance == true)
            {
                MessageBox.Show("You have already tried your chance!");
                return;
            }

            uint[] DiscountValues = { 0, 2, 3, 5, 7, 10, 15, 25, 30 };
            uint value = DiscountValues[new Random().Next(0, DiscountValues.Length)];
            ((Buyer)this.buyer).Discounts.Add(new Discount(value, 0));
            this.hasUsedChance = true;
            MessageBox.Show($"You won {value} percent discount on your purchase!");
        }
    }
}
