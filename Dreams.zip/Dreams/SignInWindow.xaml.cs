﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dreams
{
    public partial class SignInWindow : Window
    {
        private readonly string person;

        public SignInWindow(string person)
        {
            this.person = person;
            InitializeComponent();
        }

        private void Exit_Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void SignIn_Button_Click(object sender, RoutedEventArgs e)
        {
            if (person is nameof(Seller))
            {
                try
                {
                    Seller seller = Seller.SignIn(Username.Text, Password.Password);
                    SellerWindow sellerWindow = new(seller);
                    sellerWindow.Show();
                    this.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (person is nameof(Student))
            {
                try
                {
                    Student student = Student.SignIn(Username.Text, Password.Password);
                    BuyerWindow buyerWindow = new(student);
                    buyerWindow.Show();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (person is nameof(Teacher))
            {
                try
                {
                    Teacher teacher = Teacher.SignIn(Username.Text, Password.Password);
                    BuyerWindow buyerWindow = new(teacher);
                    buyerWindow.Show();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (person is nameof(Customer))
            {
                try
                {
                    Customer customer = Customer.SignIn(Username.Text, Password.Password);
                    BuyerWindow buyerWindow = new(customer);
                    buyerWindow.Show();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
